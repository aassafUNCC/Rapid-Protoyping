(function(window, undefined) {

  var jimLinks = {
    "77111612-7da8-4af0-a058-91cd74d7782d" : {
      "Button_1" : [
        "fb62ad80-5f18-4ad0-ae7b-2283ffcf4a0d"
      ]
    },
    "209a0901-8916-438b-97d4-9132372a3d4f" : {
      "Button_2" : [
        "bc84732b-ab30-423b-9b9c-af0cce88b856"
      ],
      "Button_3" : [
        "77111612-7da8-4af0-a058-91cd74d7782d"
      ]
    },
    "7069e635-6fad-4b0a-96f6-6370034d4dfa" : {
      "Button_2" : [
        "55646a2d-668d-49a9-a97a-12e71bfb24f5"
      ]
    },
    "bc84732b-ab30-423b-9b9c-af0cce88b856" : {
      "Button_1" : [
        "209a0901-8916-438b-97d4-9132372a3d4f"
      ],
      "Button_3" : [
        "3afb6e45-ed80-4b00-94a5-319551caf8b1"
      ]
    },
    "f6ccdb0f-f3ad-4d14-ad82-7bafd3e934ec" : {
    },
    "ec88167e-1178-41d6-8f19-0f580841e54d" : {
      "Button_1" : [
        "522d349f-c5c4-4a99-b062-e0d99b06d86e"
      ],
      "Button_3" : [
        "86db3c31-f67d-40e6-86e8-6371ccfc72ed"
      ]
    },
    "3afb6e45-ed80-4b00-94a5-319551caf8b1" : {
      "Button_1" : [
        "bc84732b-ab30-423b-9b9c-af0cce88b856"
      ]
    },
    "86db3c31-f67d-40e6-86e8-6371ccfc72ed" : {
      "Button_1" : [
        "ec88167e-1178-41d6-8f19-0f580841e54d"
      ]
    },
    "55646a2d-668d-49a9-a97a-12e71bfb24f5" : {
      "Button_1" : [
        "3afb6e45-ed80-4b00-94a5-319551caf8b1"
      ],
      "Button_2" : [
        "7069e635-6fad-4b0a-96f6-6370034d4dfa"
      ]
    },
    "28afc8e2-0c40-4929-81c4-2ab008043e18" : {
      "Button_1" : [
        "594830d2-fae0-46dc-91e2-26a4d9aa6949"
      ],
      "Button_2" : [
        "86db3c31-f67d-40e6-86e8-6371ccfc72ed"
      ]
    },
    "e684e86b-0f2e-4018-9ee5-036573a98e16" : {
      "Button-red" : [
        "28afc8e2-0c40-4929-81c4-2ab008043e18"
      ]
    },
    "594830d2-fae0-46dc-91e2-26a4d9aa6949" : {
      "Button_1" : [
        "86db3c31-f67d-40e6-86e8-6371ccfc72ed"
      ],
      "Button_2" : [
        "e684e86b-0f2e-4018-9ee5-036573a98e16"
      ]
    },
    "36e6290f-e3f8-468f-b2ff-3b82ff5431b3" : {
      "Button_1" : [
        "594830d2-fae0-46dc-91e2-26a4d9aa6949"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "594830d2-fae0-46dc-91e2-26a4d9aa6949"
      ],
      "Button_2" : [
        "36e6290f-e3f8-468f-b2ff-3b82ff5431b3"
      ]
    },
    "522d349f-c5c4-4a99-b062-e0d99b06d86e" : {
      "Button_1" : [
        "ec88167e-1178-41d6-8f19-0f580841e54d"
      ],
      "Button_3" : [
        "7069e635-6fad-4b0a-96f6-6370034d4dfa"
      ]
    },
    "f39803f7-df02-4169-93eb-7547fb8c961a" : {
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);