jQuery("#simulation")
  .on("click", ".s-e684e86b-0f2e-4018-9ee5-036573a98e16 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Button-red")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-e684e86b-0f2e-4018-9ee5-036573a98e16 #s-Button-red > .backgroundLayer": {
                      "attributes": {
                        "border-top-color": "#FD999A",
                        "border-right-color": "#FD999A",
                        "border-bottom-color": "#FD999A",
                        "border-left-color": "#FD999A"
                      }
                    }
                  },{
                    "#s-e684e86b-0f2e-4018-9ee5-036573a98e16 #s-Button-red span": {
                      "attributes": {
                        "color": "#FD999A"
                      }
                    }
                  },{
                    "#s-e684e86b-0f2e-4018-9ee5-036573a98e16 #s-Button-red": {
                      "attributes-ie": {
                        "border-top-color": "#FD999A",
                        "border-right-color": "#FD999A",
                        "border-bottom-color": "#FD999A",
                        "border-left-color": "#FD999A"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-e684e86b-0f2e-4018-9ee5-036573a98e16 #s-Button-red > .backgroundLayer": {
                      "attributes": {
                        "border-top-width": "1px",
                        "border-top-style": "solid",
                        "border-top-color": "#DD3214",
                        "border-right-width": "1px",
                        "border-right-style": "solid",
                        "border-right-color": "#DD3214",
                        "border-bottom-width": "1px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#DD3214",
                        "border-left-width": "1px",
                        "border-left-style": "solid",
                        "border-left-color": "#DD3214",
                        "border-radius": "5px 5px 5px 5px"
                      }
                    }
                  },{
                    "#s-e684e86b-0f2e-4018-9ee5-036573a98e16 #s-Button-red": {
                      "attributes": {
                        "font-size": "11.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#s-e684e86b-0f2e-4018-9ee5-036573a98e16 #s-Button-red .valign": {
                      "attributes": {
                        "vertical-align": "middle",
                        "text-align": "center"
                      }
                    }
                  },{
                    "#s-e684e86b-0f2e-4018-9ee5-036573a98e16 #s-Button-red span": {
                      "attributes": {
                        "color": "#DD3214",
                        "text-align": "center",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "11.0pt"
                      }
                    }
                  },{
                    "#s-e684e86b-0f2e-4018-9ee5-036573a98e16 #s-Button-red": {
                      "attributes-ie": {
                        "border-top-width": "1px",
                        "border-top-style": "solid",
                        "border-top-color": "#DD3214",
                        "border-right-width": "1px",
                        "border-right-style": "solid",
                        "border-right-color": "#DD3214",
                        "border-bottom-width": "1px",
                        "border-bottom-style": "solid",
                        "border-bottom-color": "#DD3214",
                        "border-left-width": "1px",
                        "border-left-style": "solid",
                        "border-left-color": "#DD3214",
                        "border-radius": "5px 5px 5px 5px"
                      }
                    }
                  } ],
                  "exectype": "timed",
                  "delay": 300
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/28afc8e2-0c40-4929-81c4-2ab008043e18"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });